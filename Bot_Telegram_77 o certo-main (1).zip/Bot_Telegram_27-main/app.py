import logging
import os
from functools import wraps

from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, abort

from bot_handler_new import TelegramBotHandler
from data_manager import DataManager
from scheduler import MessageScheduler

# Configuração de logs
logging.basicConfig(level=logging.INFO,
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Inicialização do Flask
app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "sua_chave_secreta_aqui")

# Inicialização dos componentes
data_manager = DataManager()
data_manager.init()

# Verificar se existe um token nos env vars e usar como padrão se não existir no data_manager
env_token = os.environ.get("TELEGRAM_TOKEN", "")
if env_token and not data_manager.get_telegram_token():
    data_manager.set_telegram_token(env_token)

# Verificar se existe um group_id nos env vars e usar como padrão se não existir no data_manager
env_group_id = os.environ.get("GROUP_ID", "")
if env_group_id and not data_manager.get_group_id():
    data_manager.set_group_id(env_group_id)

# Inicializa o bot com os valores do data_manager
token = data_manager.get_telegram_token()
group_id = data_manager.get_group_id()

bot_handler = None
scheduler = None

if token and group_id:
    bot_handler = TelegramBotHandler(token, group_id, data_manager)
    bot_handler.setup()
    
    scheduler = MessageScheduler(bot_handler, data_manager)
    scheduler.start()
else:
    logger.warning("Token ou ID do grupo não configurados. O bot não será inicializado.")

@app.route('/')
def index():
    """Página principal do painel administrativo."""
    promo_posts = data_manager.get_promo_posts()
    
    # Ordenar posts do mais recente para o mais antigo
    if promo_posts:
        promo_posts = sorted(promo_posts, key=lambda x: x.get('created_at', ''), reverse=True)
    
    return render_template('index.html', promo_posts=promo_posts[:3], 
                           bot_active=data_manager.get_bot_status(),
                           post_count=len(promo_posts),
                           interval=data_manager.get_interval())

@app.route('/welcome', methods=['GET', 'POST'])
def welcome():
    """Página de configuração da mensagem de boas-vindas."""
    if request.method == 'POST':
        welcome_message = request.form.get('welcome_message', '')
        data_manager.save_welcome_message(welcome_message)
        flash('Mensagem de boas-vindas atualizada com sucesso!', 'success')
        return redirect(url_for('welcome'))
    
    return render_template('welcome.html', 
                          welcome_message=data_manager.get_welcome_message(),
                          bot_active=data_manager.get_bot_status())

@app.route('/promo', methods=['GET', 'POST'])
def promo():
    """Página de gerenciamento de posts promocionais."""
    if request.method == 'POST':
        action = request.form.get('action')
        
        if action == 'add':
            text = request.form.get('text', '')
            image_url = request.form.get('image_url', '')
            external_link = request.form.get('external_link', '')
            
            if text:
                data_manager.add_promo_post(text, image_url, external_link)
                flash('Post promocional adicionado com sucesso!', 'success')
            else:
                flash('O texto do post não pode estar vazio!', 'danger')
        
        elif action == 'edit':
            post_id = request.form.get('id')
            text = request.form.get('text', '')
            image_url = request.form.get('image_url', '')
            external_link = request.form.get('external_link', '')
            
            if text and post_id:
                data_manager.update_promo_post(post_id, text, image_url, external_link)
                flash('Post promocional atualizado com sucesso!', 'success')
            else:
                flash('ID do post ou texto inválido!', 'danger')
        
        elif action == 'delete':
            post_id = request.form.get('id')
            
            if post_id:
                data_manager.delete_promo_post(post_id)
                flash('Post promocional excluído com sucesso!', 'success')
            else:
                flash('ID do post inválido!', 'danger')
        
        return redirect(url_for('promo'))
    
    promo_posts = data_manager.get_promo_posts()
    
    # Ordenar posts do mais recente para o mais antigo
    if promo_posts:
        promo_posts = sorted(promo_posts, key=lambda x: x.get('created_at', ''), reverse=True)
    
    return render_template('promo.html', 
                          promo_posts=promo_posts,
                          bot_active=data_manager.get_bot_status())

@app.route('/settings', methods=['GET', 'POST'])
def settings():
    """Página de configurações do bot."""
    if request.method == 'POST':
        action = request.form.get('action')
        
        if action == 'toggle_status':
            current_status = data_manager.get_bot_status()
            data_manager.set_bot_status(not current_status)
            status_text = "ativado" if not current_status else "desativado"
            flash(f'Bot {status_text} com sucesso!', 'success')
            
        elif action == 'update_interval':
            try:
                interval = int(request.form.get('interval', 10))
                if interval < 1:
                    interval = 1
                data_manager.set_interval(interval)
                if scheduler:
                    scheduler.update_interval(interval)
                flash(f'Intervalo atualizado para {interval} minutos!', 'success')
            except ValueError:
                flash('Intervalo inválido! Use apenas números.', 'danger')
        
        return redirect(url_for('settings'))
    
    return render_template('settings.html', 
                          bot_active=data_manager.get_bot_status(),
                          interval=data_manager.get_interval())

@app.route('/bot_config', methods=['GET', 'POST'])
def bot_config():
    """Página de configuração do bot."""
    global bot_handler, scheduler
    
    if request.method == 'POST':
        action = request.form.get('action')
        
        if action == 'update_credentials':
            token = request.form.get('token', '')
            group_id = request.form.get('group_id', '')
            
            old_token = data_manager.get_telegram_token()
            old_group_id = data_manager.get_group_id()
            
            data_manager.set_telegram_token(token)
            data_manager.set_group_id(group_id)
            
            # Se as credenciais mudaram, reinicia o bot
            if token != old_token or group_id != old_group_id:
                # Para o bot e o agendador existentes
                if scheduler:
                    scheduler.stop()
                if bot_handler:
                    bot_handler.stop()
                
                # Reinicia com as novas credenciais
                if token and group_id:
                    bot_handler = TelegramBotHandler(token, group_id, data_manager)
                    bot_handler.setup()
                    
                    scheduler = MessageScheduler(bot_handler, data_manager)
                    scheduler.start()
                    
                    flash('Credenciais do bot atualizadas e bot reiniciado!', 'success')
                else:
                    flash('Credenciais atualizadas, mas bot não iniciado devido a credenciais vazias.', 'warning')
            else:
                flash('Credenciais do bot atualizadas!', 'success')
                
        return redirect(url_for('bot_config'))
    
    return render_template('bot_config.html', 
                          token=data_manager.get_telegram_token(),
                          group_id=data_manager.get_group_id(),
                          bot_active=data_manager.get_bot_status())

@app.route('/api/status')
def get_status():
    """Endpoint da API para obter o status atual do bot."""
    return jsonify({
        'active': data_manager.get_bot_status(),
        'interval': data_manager.get_interval()
    })

@app.route('/test_send', methods=['GET'])
def test_send():
    """Endpoint para testar o envio de mensagens."""
    if not bot_handler:
        flash("Bot não inicializado. Configure o token e ID do grupo primeiro.", "danger")
        return redirect(url_for('bot_config'))
        
    try:
        success = bot_handler.send_message("Teste de mensagem do painel administrativo!")
        if success:
            flash("Mensagem de teste enviada com sucesso!", "success")
        else:
            flash("Falha ao enviar mensagem de teste.", "danger")
    except Exception as e:
        flash(f"Erro ao enviar mensagem: {e}", "danger")
    return redirect(url_for('index'))

@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

@app.errorhandler(500)
def server_error(e):
    return render_template('500.html'), 500

# Limpar recursos ao encerrar a aplicação
import atexit

def cleanup():
    """Função para limpar recursos ao encerrar a aplicação."""
    logger.info("Encerrando aplicação e limpando recursos...")
    if scheduler:
        scheduler.stop()
    if bot_handler:
        bot_handler.stop()

atexit.register(cleanup)
