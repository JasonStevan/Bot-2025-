import logging
import threading
import time
import random
import requests
import json

logger = logging.getLogger(__name__)

class TelegramBotHandler:
    """Gerencia a funcionalidade do bot do Telegram."""
    
    def __init__(self, token, group_id, data_manager):
        """Inicializa o manipulador do bot do Telegram.
        
        Args:
            token (str): Token de API do bot do Telegram.
            group_id (str): ID do grupo do Telegram.
            data_manager (DataManager): Instância do gerenciador de dados.
        """
        self.token = token
        self.group_id = group_id
        self.data_manager = data_manager
        self.base_url = f"https://api.telegram.org/bot{token}"
        self.update_offset = 0
        self.running = False
        self.thread = None
        self.check_interval = 60  # segundos
        
        # Inicializa um ID para mensagens
        self.next_message_id = random.randint(1000, 9999)
        
        logger.info(f"Bot inicializado para o grupo {group_id}")
    
    def _get_bot_info(self):
        """Obtém informações do bot."""
        try:
            response = requests.get(f"{self.base_url}/getMe")
            if response.status_code == 200:
                return response.json().get('result', {})
            else:
                logger.error(f"Erro ao obter informações do bot: {response.status_code} - {response.text}")
                return {}
        except Exception as e:
            logger.error(f"Falha ao obter informações do bot: {e}")
            return {}
    
    def setup(self):
        """Configura o bot do Telegram com manipuladores."""
        if not self.running:
            self.running = True
            
            # Inicia o bot em modo não bloqueante
            self._start_bot()
            
            logger.info("Bot configurado e thread de verificação iniciada")
            
            # Loga informações do bot
            bot_info = self._get_bot_info()
            if bot_info:
                logger.info(f"Bot conectado: @{bot_info.get('username')} ({bot_info.get('first_name')})")
            else:
                logger.warning("Não foi possível obter informações do bot")
        else:
            logger.warning("Bot já está em execução")
    
    def _check_for_new_members(self):
        """Verifica novos membros periodicamente diretamente via API."""
        try:
            response = requests.get(
                f"{self.base_url}/getUpdates",
                params={"offset": self.update_offset, "timeout": 5}
            )
            
            if response.status_code != 200:
                logger.error(f"Erro ao buscar atualizações: {response.status_code} - {response.text}")
                return
            
            updates = response.json().get('result', [])
            
            for update in updates:
                update_id = update.get('update_id')
                self.update_offset = update_id + 1
                
                # Verificar mensagens do chat
                if 'message' in update:
                    message = update.get('message', {})
                    
                    # Verificar novos membros
                    if 'new_chat_members' in message:
                        new_members = message.get('new_chat_members', [])
                        
                        # Se houver novos membros, envia mensagem de boas-vindas
                        for member in new_members:
                            if not member.get('is_bot'):
                                logger.info(f"Novo membro detectado via API: {member.get('first_name')}")
                                self.send_welcome_message({
                                    'first_name': member.get('first_name', ''),
                                    'last_name': member.get('last_name', ''),
                                    'username': member.get('username', '')
                                })
        
        except Exception as e:
            logger.error(f"Erro ao verificar novos membros: {e}")
    
    def _start_bot(self):
        """Inicia o bot em modo não bloqueante."""
        if not self.thread or not self.thread.is_alive():
            self.thread = threading.Thread(target=self._start_polling)
            self.thread.daemon = True
            self.thread.start()
            logger.info("Thread de polling do bot iniciada")
    
    def stop(self):
        """Para o polling do bot."""
        self.running = False
        logger.info("Bot definido para parar")
    
    def _start_polling(self):
        """Inicia o polling em uma thread."""
        logger.info("Polling iniciado")
        while self.running and self.data_manager.get_bot_status():
            try:
                self._check_for_new_members()
                time.sleep(self.check_interval)  # Usa o intervalo configurado
            except Exception as e:
                logger.error(f"Erro durante o polling: {e}")
        
        logger.info("Polling encerrado")
    
    def send_message(self, text, image_url=None):
        """Envia uma mensagem para o grupo usando requisição HTTP direta.
        
        Args:
            text (str): Texto da mensagem.
            image_url (str, opcional): URL da imagem a ser enviada.
            
        Returns:
            bool: True se a mensagem foi enviada com sucesso, False caso contrário.
        """
        if not self.data_manager.get_bot_status():
            logger.warning("Tentativa de enviar mensagem com bot desativado")
            return False
        
        try:
            if image_url:
                # Se for uma mensagem com imagem, usa o método sendPhoto
                response = requests.post(
                    f"{self.base_url}/sendPhoto",
                    json={
                        "chat_id": self.group_id,
                        "photo": image_url,
                        "caption": text,
                        "parse_mode": "HTML"
                    }
                )
            else:
                # Senão, envia apenas texto
                response = self._send_text_message(text)
                
            if response.status_code == 200:
                logger.info(f"Mensagem enviada com sucesso: {text[:50]}...")
                return True
            else:
                logger.error(f"Erro ao enviar mensagem: {response.status_code} - {response.text}")
                return False
                
        except Exception as e:
            logger.error(f"Falha ao enviar mensagem: {e}")
            return False
    
    def _send_text_message(self, text):
        """Método auxiliar para enviar apenas texto.
        
        Args:
            text (str): Texto da mensagem.
            
        Returns:
            Response: Objeto de resposta da requisição.
        """
        return requests.post(
            f"{self.base_url}/sendMessage",
            json={
                "chat_id": self.group_id,
                "text": text,
                "parse_mode": "HTML"
            }
        )
    
    def send_welcome_message(self, user_info):
        """Envia uma mensagem de boas-vindas para um novo membro.
        
        Args:
            user_info (dict): Informações do usuário (first_name, last_name, username).
        """
        if not self.data_manager.get_bot_status():
            logger.warning("Tentativa de enviar mensagem de boas-vindas com bot desativado")
            return False
        
        # Obtém o template da mensagem de boas-vindas
        welcome_template = self.data_manager.get_welcome_message()
        
        # Formata a mensagem substituindo as variáveis pelos valores reais
        message = welcome_template.format(
            first_name=user_info.get('first_name', 'usuário'),
            last_name=user_info.get('last_name', ''),
            username=user_info.get('username', '')
        )
        
        logger.info(f"Enviando mensagem de boas-vindas para {user_info.get('first_name')}")
        
        # Envia a mensagem formatada
        return self.send_message(message)
    
    def send_random_promo(self):
        """Envia uma postagem promocional aleatória para o grupo.
        
        Returns:
            bool: True se a mensagem foi enviada com sucesso, False caso contrário.
        """
        if not self.data_manager.get_bot_status():
            logger.warning("Tentativa de enviar promoção com bot desativado")
            return False
        
        # Busca posts diretamente para evitar problemas de cache
        promo_posts = self.data_manager.get_promo_posts()
        
        if not promo_posts:
            logger.warning("Nenhum post promocional disponível")
            return False
        
        # Seleciona um post aleatório
        post = random.choice(promo_posts)
        
        # Prepara o texto da mensagem
        text = post.get('text', '')
        
        # Adiciona link externo, se existir
        external_link = post.get('external_link', '')
        if external_link:
            text += f"\n\n<a href='{external_link}'>Mais informações aqui</a>"
        
        # Envia a mensagem com imagem, se existir
        image_url = post.get('image_url', '')
        
        # Log adicional para debug
        logger.info(f"Enviando post promocional: ID={post.get('id')}, início do texto: {text[:50]}...")
        
        return self.send_message(text, image_url)
