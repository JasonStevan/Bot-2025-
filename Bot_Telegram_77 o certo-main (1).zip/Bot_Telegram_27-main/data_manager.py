import json
import logging
import os
import uuid
from datetime import datetime

# Configuração de logs
logging.basicConfig(level=logging.INFO,
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class DataManager:
    """Gerencia o armazenamento de dados para o bot."""
    
    def __init__(self):
        """Inicializa o gerenciador de dados."""
        self.data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
        self.config_file = os.path.join(self.data_dir, 'config.json')
        self.promo_file = os.path.join(self.data_dir, 'promo_posts.json')
        self.welcome_file = os.path.join(self.data_dir, 'welcome_message.txt')
        
        self.config = {
            "bot_active": False,
            "interval": 10,  # 10 minutos por padrão
            "telegram_token": "",
            "group_id": ""
        }
        
        self.promo_posts = []
        self.welcome_message = "Olá {first_name}! 👋 Seja muito bem-vindo(a) ao nosso grupo! Estamos felizes em ter você aqui conosco."
        
    def init(self):
        """Inicializa o armazenamento de dados."""
        # Cria o diretório de dados se não existir
        if not os.path.exists(self.data_dir):
            os.makedirs(self.data_dir)
            
        # Carrega ou cria o arquivo de configuração
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, 'r') as f:
                    self.config = json.load(f)
            except Exception as e:
                logger.error(f"Erro ao carregar arquivo de configuração: {e}")
        else:
            self._save_config()
            
        # Carrega ou cria o arquivo de posts promocionais
        if os.path.exists(self.promo_file):
            try:
                with open(self.promo_file, 'r') as f:
                    self.promo_posts = json.load(f)
            except Exception as e:
                logger.error(f"Erro ao carregar arquivo de posts promocionais: {e}")
        else:
            # Adiciona um post promocional padrão antes de salvar
            self._add_default_promo_post()
            self._save_promo_posts()
            
        # Se depois de carregar, ainda não houver posts, adicione um padrão
        if not self.promo_posts:
            self._add_default_promo_post()
            self._save_promo_posts()
            
        # Carrega ou cria o arquivo de mensagem de boas-vindas
        if os.path.exists(self.welcome_file):
            try:
                with open(self.welcome_file, 'r') as f:
                    self.welcome_message = f.read()
            except Exception as e:
                logger.error(f"Erro ao carregar arquivo de mensagem de boas-vindas: {e}")
        else:
            self._save_welcome_message()
            
        logger.info("Gerenciador de dados inicializado")
        
    def _add_default_promo_post(self):
        """Adiciona um post promocional padrão."""
        post = {
            "id": str(uuid.uuid4()),
            "text": "• Acesso a mais de 100 milhões de imagens e elementos\n• Mais de 610.000 templates premium\n• Remove fundos de imagens com um clique\n\nAdquira hoje mesmo o Canva Pro para aproveitar!\n\nDesign profissional ao seu alcance!\nAdquira o Canva Pro agora mesmo.\nFale com @JasonStevan no privado.\n\nBenefícios do Canva Pro:\n• Edite imagens como um profissional\n• Crie apresentações de impacto\n• Acesso a fontes exclusivas premium\n• Magic Studio: recursos de IA para designs incríveis\n\nAdquira hoje mesmo o Canva Pro para aproveitar!",
            "image_url": "https://i.postimg.cc/XqnWzQ8h/canva-pro.jpg",
            "external_link": "https://www.canva.com/pro/",
            "created_at": datetime.now().isoformat()
        }
        self.promo_posts.append(post)
        logger.info("Post promocional padrão adicionado")
        
    def _save_config(self):
        """Salva a configuração no arquivo."""
        try:
            with open(self.config_file, 'w') as f:
                json.dump(self.config, f, indent=2)
        except Exception as e:
            logger.error(f"Erro ao salvar arquivo de configuração: {e}")
            
    def _save_promo_posts(self):
        """Salva os posts promocionais no arquivo."""
        try:
            with open(self.promo_file, 'w') as f:
                json.dump(self.promo_posts, f, indent=2)
            logger.info(f"Posts promocionais salvos com sucesso em {self.promo_file}")
        except Exception as e:
            logger.error(f"Erro ao salvar arquivo de posts promocionais: {e}")
            
    def _save_welcome_message(self):
        """Salva a mensagem de boas-vindas no arquivo."""
        try:
            with open(self.welcome_file, 'w') as f:
                f.write(self.welcome_message)
        except Exception as e:
            logger.error(f"Erro ao salvar arquivo de mensagem de boas-vindas: {e}")
    
    def get_bot_status(self):
        """Obtém o status atual do bot."""
        return self.config.get("bot_active", False)
        
    def set_bot_status(self, active):
        """Define o status ativo do bot."""
        self.config["bot_active"] = active
        self._save_config()
        logger.info(f"Status do bot definido para {active}")
        
    def get_interval(self):
        """Obtém o intervalo dos posts promocionais."""
        return self.config.get("interval", 10)  # Padrão para 10 minutos
        
    def set_interval(self, minutes):
        """Define o intervalo dos posts promocionais."""
        self.config["interval"] = minutes
        self._save_config()
        logger.info(f"Intervalo definido para {minutes} minutos")
        
    def get_welcome_message(self):
        """Obtém o modelo de mensagem de boas-vindas."""
        return self.welcome_message
        
    def save_welcome_message(self, message):
        """Salva o modelo de mensagem de boas-vindas."""
        self.welcome_message = message
        self._save_welcome_message()
        logger.info("Mensagem de boas-vindas atualizada")
        
    def get_promo_posts(self):
        """Obtém todos os posts promocionais, recarregando do arquivo."""
        if os.path.exists(self.promo_file):
            try:
                with open(self.promo_file, 'r') as f:
                    self.promo_posts = json.load(f)
            except Exception as e:
                logger.error(f"Erro ao recarregar posts promocionais: {e}")
        return self.promo_posts
        
    def add_promo_post(self, text, image_url="", external_link=""):
        """Adiciona um novo post promocional."""
        post = {
            "id": str(uuid.uuid4()),
            "text": text,
            "image_url": image_url,
            "external_link": external_link,
            "created_at": datetime.now().isoformat()
        }
        self.promo_posts.append(post)
        self._save_promo_posts()
        logger.info(f"Adicionado novo post promocional com ID {post['id']}")
        return post
        
    def update_promo_post(self, post_id, text, image_url="", external_link=""):
        """Atualiza um post promocional existente."""
        for post in self.promo_posts:
            if post["id"] == post_id:
                # Armazena o texto antigo para logging
                old_text = post["text"]
                
                # Atualiza os dados
                post["text"] = text
                post["image_url"] = image_url
                post["external_link"] = external_link
                post["updated_at"] = datetime.now().isoformat()
                
                # Salva imediatamente para garantir persistência
                self._save_promo_posts()
                
                logger.info(f"Atualizado post promocional com ID {post_id}")
                logger.info(f"Texto antigo: {old_text[:30]}...")
                logger.info(f"Texto novo: {text[:30]}...")
                
                return post
                
        logger.warning(f"Post promocional com ID {post_id} não encontrado para atualização")
        return None
        
    def delete_promo_post(self, post_id):
        """Exclui um post promocional."""
        for i, post in enumerate(self.promo_posts):
            if post["id"] == post_id:
                del self.promo_posts[i]
                self._save_promo_posts()
                logger.info(f"Excluído post promocional com ID {post_id}")
                return True
                
        logger.warning(f"Post promocional com ID {post_id} não encontrado para exclusão")
        return False

    def get_telegram_token(self):
        """Obtém o token do bot do Telegram."""
        return self.config.get("telegram_token", "")
    
    def set_telegram_token(self, token):
        """Define o token do bot do Telegram."""
        self.config["telegram_token"] = token
        self._save_config()
        logger.info("Token do Telegram atualizado")
    
    def get_group_id(self):
        """Obtém o ID do grupo do Telegram."""
        return self.config.get("group_id", "")
    
    def set_group_id(self, group_id):
        """Define o ID do grupo do Telegram."""
        self.config["group_id"] = group_id
        self._save_config()
        logger.info("ID do grupo atualizado")
