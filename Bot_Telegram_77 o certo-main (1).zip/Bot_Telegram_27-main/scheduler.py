import logging
import threading
import time
import random

logger = logging.getLogger(__name__)

class MessageScheduler:
    """Gerencia o agendamento de mensagens promocionais."""
    
    def __init__(self, bot_handler, data_manager):
        """Inicializa o agendador de mensagens.
        
        Args:
            bot_handler (TelegramBotHandler): Manipulador do bot do Telegram.
            data_manager (DataManager): Gerenciador de dados.
        """
        self.bot_handler = bot_handler
        self.data_manager = data_manager
        self.interval = data_manager.get_interval()
        self.running = False
        self.thread = None
        
        logger.info(f"Agendador inicializado com intervalo de {self.interval} minutos")
    
    def start(self):
        """Inicia a thread do agendador."""
        if not self.running:
            self.running = True
            self.thread = threading.Thread(target=self._schedule_loop)
            self.thread.daemon = True
            self.thread.start()
            logger.info("Thread do agendador iniciada")
    
    def stop(self):
        """Para a thread do agendador."""
        self.running = False
        logger.info("Agendador definido para parar")
    
    def update_interval(self, minutes):
        """Atualiza o intervalo de agendamento.
        
        Args:
            minutes (int): Intervalo em minutos.
        """
        self.interval = minutes
        logger.info(f"Intervalo de agendamento atualizado para {minutes} minutos")
    
    def _schedule_loop(self):
        """Loop principal de agendamento."""
        logger.info("Loop do agendador iniciado")
        
        while self.running:
            # Adiciona uma variação aleatória ao intervalo para parecer mais natural
            # Entre 90% e 110% do intervalo definido
            interval_seconds = self.interval * 60
            jitter = random.uniform(0.9, 1.1)
            sleep_time = interval_seconds * jitter
            
            # Logs apenas para depuração
            logger.info(f"Próxima mensagem promocional em {sleep_time/60:.2f} minutos")
            
            # Aguarda o tempo do intervalo
            time.sleep(sleep_time)
            
            # Verifica se o bot está ativo antes de enviar
            if self.data_manager.get_bot_status() and self.running:
                logger.info("Enviando post promocional agendado")
                try:
                    result = self.bot_handler.send_random_promo()
                    if result:
                        logger.info("Post promocional enviado com sucesso")
                    else:
                        logger.error("Falha ao enviar post promocional")
                except Exception as e:
                    logger.error(f"Erro ao enviar post promocional: {e}")
