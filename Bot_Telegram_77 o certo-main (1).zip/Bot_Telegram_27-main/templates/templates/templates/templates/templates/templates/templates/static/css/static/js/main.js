document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Initialize popovers
    const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });

    // Setup flash message auto-dismissal
    const flashMessages = document.querySelectorAll('.alert-dismissible');
    flashMessages.forEach(function(alert) {
        setTimeout(function() {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000); // Auto dismiss after 5 seconds
    });

    // Poll bot status for live updates
    function pollBotStatus() {
        fetch('/api/status')
            .then(response => response.json())
            .then(data => {
                updateStatusIndicator(data.status);
            })
            .catch(error => console.error('Error polling bot status:', error));
    }

    // Update the status indicator based on bot status
    function updateStatusIndicator(status) {
        const indicators = document.querySelectorAll('.status-indicator');
        
        indicators.forEach(indicator => {
            if (status) {
                indicator.classList.remove('status-inactive');
                indicator.classList.add('status-active');
            } else {
                indicator.classList.remove('status-active');
                indicator.classList.add('status-inactive');
            }
        });

        const statusTexts = document.querySelectorAll('.status-text');
        statusTexts.forEach(text => {
            text.textContent = status ? 'Ativo' : 'Inativo';
        });

        const toggleButtons = document.querySelectorAll('.toggle-bot-btn');
        toggleButtons.forEach(btn => {
            btn.textContent = status ? 'Desativar Bot' : 'Ativar Bot';
            btn.classList.remove(status ? 'btn-success' : 'btn-danger');
            btn.classList.add(status ? 'btn-danger' : 'btn-success');
        });
    }

    // Setup edit form for promotional posts
    function setupEditPromo() {
        const editButtons = document.querySelectorAll('.edit-promo-btn');
        
        editButtons.forEach(button => {
            button.addEventListener('click', function() {
                const postId = this.getAttribute('data-id');
                const postText = document.querySelector(`#promo-text-${postId}`).textContent;
                const postImageUrl = this.getAttribute('data-image-url');
                const postExternalLink = this.getAttribute('data-external-link');
                
                // Fill the edit form
                document.querySelector('#edit-form-id').value = postId;
                document.querySelector('#edit-form-text').value = postText;
                document.querySelector('#edit-form-image-url').value = postImageUrl || '';
                
                // Preenche o campo de link externo se existir o elemento
                const externalLinkField = document.querySelector('#edit-form-external-link');
                if (externalLinkField) {
                    externalLinkField.value = postExternalLink || '';
                }
            });
        });
    }

    // Setup delete confirmation for promotional posts
    function setupDeletePromo() {
        const deleteButtons = document.querySelectorAll('.delete-promo-btn');
        
        deleteButtons.forEach(button => {
            button.addEventListener('click', function() {
                const postId = this.getAttribute('data-id');
                document.querySelector('#delete-form-id').value = postId;
            });
        });
    }

    // Initialize mobile navigation
    function initMobileNav() {
        const currentPath = window.location.pathname;
        const navLinks = document.querySelectorAll('.mobile-nav a');
        
        navLinks.forEach(link => {
            const linkPath = link.getAttribute('href');
            if (currentPath === linkPath) {
                link.classList.add('active');
            }
        });
    }

    // Form validation for all forms
    const forms = document.querySelectorAll('.needs-validation');
    Array.from(forms).forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    });

    // Initialize functionality if elements exist
    if (document.querySelector('.edit-promo-btn')) {
        setupEditPromo();
    }
    
    if (document.querySelector('.delete-promo-btn')) {
        setupDeletePromo();
    }
    
    if (document.querySelector('.mobile-nav')) {
        initMobileNav();
    }

    // Poll bot status every 30 seconds
    if (document.querySelector('.status-indicator')) {
        pollBotStatus(); // Initial poll
        setInterval(pollBotStatus, 30000); // Poll every 30 seconds
    }
    
    // Preview image URL when entered
    const imageUrlInputs = document.querySelectorAll('.image-url-input');
    const previewContainers = document.querySelectorAll('.image-preview');
    
    imageUrlInputs.forEach((input, index) => {
        if (previewContainers[index]) {
            input.addEventListener('input', function() {
                const url = this.value.trim();
                const previewContainer = previewContainers[index];
                
                if (url) {
                    previewContainer.innerHTML = `<div class="mt-2">
                        <img src="${url}" class="img-fluid rounded" alt="Preview" 
                            onerror="this.onerror=null;this.src='';this.alt='Invalid image URL';
                            this.parentNode.classList.add('text-danger');">
                    </div>`;
                } else {
                    previewContainer.innerHTML = '';
                }
            });
            
            // Trigger preview for existing URLs
            if (input.value.trim()) {
                input.dispatchEvent(new Event('input'));
            }
        }
    });
});
